﻿using kasatkin8var.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;


namespace kasatkin8var.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageServices.xaml
    /// </summary>
    public partial class PageServices : Page
    {
        public PageServices()
        {
            InitializeComponent();
            DtgService.ItemsSource = okazaniyeuslugEntities.GetContext().Services.ToList();
        }

        private void DtgRepair_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DtgService_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void SearchService_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgService.ItemsSource != null)
            {
                DtgService.ItemsSource = okazaniyeuslugEntities.GetContext().Services.Where(x => x.Name.ToLower().Contains(Service.Text.ToLower())).ToList();
            }
            if (Service.Text.Count() == 0) DtgService.ItemsSource = okazaniyeuslugEntities.GetContext().Services.ToList();
        }
    }
}
